import React from 'react'

const Cards = (props) => {
  return (
    <div >
     <div style={{margin:"30px",width:"150px"}}>
        <img src={props.img_data} style={{height:"150px",width:"150px"}}></img>
        <h4 >2500</h4>
        <p>fdg</p>
    </div>
    </div>
   
  )
}

export default Cards