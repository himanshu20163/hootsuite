import React from 'react'

const Hwa = () => {
  return (
    <div>
        <div className='header'>
          
        </div>
        <div className='slider'>

        </div>
        <div className='footer'>
            
        </div>
    </div>
  )
}

export default Hwa